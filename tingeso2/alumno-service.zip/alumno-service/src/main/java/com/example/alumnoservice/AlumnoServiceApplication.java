package com.example.alumnoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlumnoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlumnoServiceApplication.class, args);
	}

}
