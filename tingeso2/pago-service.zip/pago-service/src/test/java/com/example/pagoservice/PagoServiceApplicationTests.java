package com.example.pagoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
