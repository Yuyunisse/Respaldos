package com.example.TopAlumno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopAlumnoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TopAlumnoApplication.class, args);
	}

}
