package com.example.TopAlumno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopAlumnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
